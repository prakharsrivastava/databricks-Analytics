-- Databricks notebook source
-- MAGIC %run ./Classroom-Setup-Common

-- COMMAND ----------

-- Change the default catalog/schema to teach how to do this in class.
USE CATALOG samples;
USE SCHEMA nyctaxi;