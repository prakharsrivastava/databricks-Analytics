-- Databricks notebook source
-- CREATE DA VARIABLE USING SQL FOR USER INFORMATION FROM THE META TABLE

-- Create a temp view storing information from the obs table.
CREATE OR REPLACE TEMP VIEW user_info AS
SELECT map_from_arrays(collect_list(replace(key,'.','_')), collect_list(value))
FROM dbacademy.ops.meta;

-- Create SQL dictionary var (map)
DECLARE OR REPLACE DA MAP<STRING,STRING>;

-- Set the temp view in the DA variable
SET VAR DA = (SELECT * FROM user_info);

DROP VIEW IF EXISTS user_info;

-- COMMAND ----------

-- Set the default catalog + schema
USE CATALOG dbacademy;
USE SCHEMA IDENTIFIER(DA.schema_name);

-- COMMAND ----------

-- Check to make sure all necessary tables are in the user's schema. Otherwise return an error message
DECLARE OR REPLACE VARIABLE user_table_count INT DEFAULT 7;

DECLARE OR REPLACE VARIABLE required_table_list ARRAY<STRING> 
  DEFAULT ARRAY('aus_customers', 'aus_opportunities', 'aus_orders',  
                'ca_customers', 'ca_opportunities', 'ca_orders','au_products_lookup');

SELECT
  CASE 
    WHEN COUNT(table_name) = user_table_count THEN 'Lab Check, all tables available for your lab!'  -- Adjust '3' to the number of tables you are checking
    ELSE '---ERROR: Tables in your lab are missing. Please rerun notebook 0 - REQUIRED - Course Setup to setup your environment.---'
  END AS table_status
FROM information_schema.tables
WHERE table_schema = DA.schema_name AND 
      table_name IN (SELECT EXPLODE(required_table_list));